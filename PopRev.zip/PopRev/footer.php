<?php wp_footer(); ?>
<?php
$instagram = get_field('instagram', 'options');
$facebook = get_field('facebook', 'options');
$twitter = get_field('twitter', 'options');
$youtube = get_field('youtube', 'options');
$copyright_text = get_field('copyright_text', 'options');
?>
<!--region footer-->
<footer>
  <div class="container">
    <div class="footer-content">
      <ul class="social-media">
        <li class="social-icon"><a href="<?= $twitter ?>" target="_blank">
            <svg
              viewBox="0 0 21 17">
              <path fill="#fff"
                    d="M20.056 2.611a7.985 7.985 0 0 1-2.296.63 4.015 4.015 0 0 0 1.758-2.21c-.775.457-1.63.79-2.541.97a3.999 3.999 0 0 0-6.814 3.646 11.352 11.352 0 0 1-8.24-4.178 3.968 3.968 0 0 0-.542 2.01c0 1.387.707 2.61 1.779 3.327a3.999 3.999 0 0 1-1.812-.502v.05a4.003 4.003 0 0 0 3.207 3.92 4.05 4.05 0 0 1-1.053.14c-.258 0-.508-.025-.753-.073a4 4 0 0 0 3.735 2.777 8.023 8.023 0 0 1-4.966 1.709c-.323 0-.641-.02-.954-.055a11.303 11.303 0 0 0 6.13 1.799c7.355 0 11.375-6.093 11.375-11.376l-.013-.518a7.985 7.985 0 0 0 2-2.066z"/>
            </svg>
          </a></li>
        <li class="social-icon"><a href="<?= $instagram ?>"
                                   target="_blank">
            <svg
              viewBox="0 0 20 20">
              <path fill="#fff"
                    d="M17.658 13.778c0 2.288-1.906 4.15-4.249 4.15H6.126c-2.342 0-4.248-1.862-4.248-4.15V6.664c0-2.288 1.906-4.15 4.248-4.15h7.283c2.343 0 4.249 1.862 4.249 4.15zM13.409.736H6.126C2.775.736.057 3.391.057 6.664v7.114c0 3.273 2.718 5.927 6.07 5.927h7.282c3.352 0 6.07-2.654 6.07-5.927V6.664c0-3.273-2.718-5.928-6.07-5.928z"/>
              <path fill="#fff"
                    d="M9.768 13.64a3.424 3.424 0 0 1-3.42-3.42 3.424 3.424 0 0 1 3.42-3.419 3.424 3.424 0 0 1 3.42 3.42 3.424 3.424 0 0 1-3.42 3.42zm0-8.89a5.472 5.472 0 1 0 0 10.943 5.472 5.472 0 0 0 0-10.944z"/>
              <path fill="#fff"
                    d="M14.21 5.179a.73.73 0 1 1 1.459 0 .73.73 0 0 1-1.458 0z"/>
            </svg>
          </a></li>
        <li class="social-icon"><a href="<?= $facebook ?>" target="_blank">
            <svg
              viewBox="0 0 10 19">
              <path fill="#fff"
                    d="M6.135 6.358L6.139 4.8c0-.812.057-1.247 1.22-1.247h2.154V.436H6.428c-2.994 0-3.683 1.547-3.683 4.087l.003 1.835-2.272.001v3.115h2.272v9.038h3.388l.002-9.038 3.077-.001.33-3.115z"/>
            </svg>
          </a></li>
        <li class="social-icon"><a href="<?= $youtube ?>" target="_blank">
            <svg
              viewBox="0 0 22 15">
              <path fill="#fff"
                    d="M21.088 1.701C20.506.666 19.874.476 18.588.403 17.305.316 14.075.28 11.277.28c-2.803 0-6.035.036-7.318.122C2.675.476 2.042.665 1.455 1.7.855 2.735.547 4.515.547 7.65v.011c0 3.121.309 4.915.908 5.938.587 1.035 1.219 1.223 2.502 1.31 1.284.075 4.516.12 7.32.12 2.797 0 6.027-.045 7.313-.119 1.286-.087 1.917-.274 2.5-1.31.604-1.023.91-2.817.91-5.938v-.007-.004c0-3.136-.306-4.916-.912-5.95zM8.592 11.676V3.632l6.704 4.022z"/>
            </svg>
          </a></li>
      </ul>
      <p class="paragraph paragraph-18"><?= $copyright_text ?></p>
    </div>
  </div>
</footer>
<!--endregion footer-->
</main>
<section class="popup_block" data-section-class="popup_block">
  <div class="container">
    <div class="popup">
      <div class="left-content">
        <div class="top-part">
          <div class="logo">
            <img src="<?= get_template_directory_uri() ?>/assets/images/o-logo.png" alt="">
          </div>
          <div class="close-icon">
            <span class="x-line"></span>
            <span class="x-line"></span>
          </div>
          <p class="popup-title">STAY <span class="yellow">TUNED</span></p>
          <p class="paragraph">Subscribe to our Newsletter for investment
            updates, artists’ performance, Draftpicks and lots of super
            perks. Don’t forget our surprise BTS experience and specially
            curated events.</p>
          <?= do_shortcode('[quform id="2" name="Newsletter"]'); ?>
          <!--          <form action="">-->
          <!--            <input type="email" class="email" placeholder="Enter your email">-->
          <!--            <button type="submit" class="submit" name="foo" value="bar">-->
          <!--              SUBMIT-->
          <!--              <svg id="submit" viewBox="0 0 70.01 70">-->
          <!--                <g>-->
          <!--                  <path id="Path_1559" data-name="Path 1559" d="M35,6.26,54.59,44.14,35,36.36Z" fill="#313131" opacity="0.68"-->
          <!--                        style="isolation:isolate"/>-->
          <!--                  <path id="Path_1560" data-name="Path 1560"-->
          <!--                        d="M16.44,45.63,35,37.37,54.25,45a.93.93,0,0,0,1-.21l0,0a.92.92,0,0,0,.13-1L35.82,5.84a.36.36,0,0,0-.07-.1l-.08-.11a1.16,1.16,0,0,0-.21-.16s0,0-.05,0a0,0,0,0,0,0,0,.89.89,0,0,0-.32-.08H35l-.18,0,0,0-.12.05a.52.52,0,0,0-.18.1.36.36,0,0,0-.09.08,1.24,1.24,0,0,0-.14.18s0,0,0,.06L15.24,44.38a.92.92,0,0,0,1.2,1.25Zm36.2-3.26L35.93,35.74V10.06ZM34.08,10.24V35.76L18,42.91Z"-->
          <!--                        fill="#fff"/>-->
          <!---->
          <!--                </g>-->
          <!--                <g class="rocket-fire">-->
          <!--                  <path id="Path_1561" data-name="Path 1561"-->
          <!--                        d="M35.66,64.38a1,1,0,0,0,.27-.66V45.44a.92.92,0,1,0-1.84,0V63.72a.93.93,0,0,0,.92.93,1,1,0,0,0,.66-.27Z"-->
          <!--                        fill="#fff"/>-->
          <!--                  <path id="Path_1562" data-name="Path 1562" d="M41.26,47.4v9.14a.93.93,0,0,0,1.85,0V47.4a.93.93,0,0,0-1.85,0Z"-->
          <!--                        fill="#fff"/>-->
          <!--                  <path id="Path_1563" data-name="Path 1563"-->
          <!--                        d="M28.47,57.19a.88.88,0,0,0,.27-.65V47.4a.92.92,0,1,0-1.84,0v9.14a.93.93,0,0,0,.92.93A.88.88,0,0,0,28.47,57.19Z"-->
          <!--                        fill="#fff"/>-->
          <!--                </g>-->
          <!---->
          <!--              </svg>-->
          <!--            </button>-->
          <!--          </form>-->
        </div>
        <div class="follow-us">
          <p class="follow-us-title">FOLLOW US ON</p>
          <ul class="social-media">
            <li class="link-wrapper">
              <a href="#">Instagram</a>
            </li>
            <li class="link-wrapper">
              <a href="#">TikTok</a>
            </li>
            <li class="link-wrapper">
              <a href="#">Twitter</a>
            </li>
          </ul>
        </div>
      </div>
      <div class="right-content">
        <picture>
          <img src="<?= get_template_directory_uri() ?>/assets/images/durag.png" alt="">
        </picture>
      </div>
    </div>
  </div>
</section>
<!--region if Moaz-->
<?php
$user = wp_get_current_user();
if ($user && isset($user->user_login) && 'moaz' == $user->user_login) { ?>
  <style>
    header {
      display: none !important;
    }
  </style>
<?php } ?>
<!--endregion if Moaz-->
<div class="video-modal custom-modal" id="custom-modal">
  <div class="custom-modal-inner">
    <button class="close-modal" aria-label="Close Modal">
      <svg height="16" viewBox="0 0 17 16" width="17" xmlns="http://www.w3.org/2000/svg">
        <path d="M16.274 1.676L14.6 0l-6.19 6.19L2.22 0 .545 1.676l6.19 6.189-6.19 6.19L2.22 15.73l6.19-6.19 6.189 6.19 1.675-1.676-6.189-6.189z" fill="#9899a2"/>
      </svg>
    </button>
    <div class="custom-modal-wrap">

    </div>
  </div>
</div>
</body>
</html>
