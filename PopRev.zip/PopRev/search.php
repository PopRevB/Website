<?php
/**
 * The template for displaying search results pages
 *
 * @link    https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Zephyr
 */

get_header();
?>
  <section class="hero-blog-pages">
    <img alt="services-02-image-1" class="image" data-src="<?=get_template_directory_uri() . '/assets/images/services-02-image-1.png'?>">
    <div class="black-layout"></div>
    <div class="container block-hero-number-wrapper">
      <div class="text-hero">
        <h1 class="headline-1">Search</h1>
        <h2 style="color: var(--poprev-white)"> Results For
          <span><?php echo get_search_query() ?></h2>
      </div>
    </div>
  </section>
  <div class="container">
    <div class="loop-page-wrapper">
      <div class="row ajax-posts">
        <?php if (have_posts()) : ?>
          <?php post_cards_loop() ?>
        <?php else: ?>
          <p class="there-is-no-results iv-st-from-bottom">there is no search results</p>
        <?php endif; ?>
      </div>
      <?php if ($wp_query->max_num_pages > 1) { echo ' <div class="load-more iv-st-from-bottom poprev_loadmore"> <span>Load More</span> <div class="circle"></div> </div> '; } ?>
    </div>
  </div>
<?php
get_footer();
