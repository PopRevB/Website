<?php
/**
 * Template Name: Blog
 */
get_header();

$posts_page_id = get_option( 'page_for_posts' );


$title         = get_field( 'title', $posts_page_id );
$description   = get_field( 'description', $posts_page_id );
$arch_color    = get_field( 'arch_color', $posts_page_id );
$image         = get_field( 'image', $posts_page_id );
$current_year  = date( 'Y' );

$current_month = date( 'm' );
$args          = array(
  'year'     => $current_year,
  'monthnum' => $current_month,
  'order'    => 'DESC'
);

$nextMonth = date('m', strtotime('+1 month'));
$nextMonthYear = date('y', strtotime('+1 month'));
$prevMonth = date('m', strtotime('-1 month'));
$prevMonthYear = date('y', strtotime('-1 month'));
query_posts( $args );

$is_tax_page    = is_tax() || is_category();
$posts_per_page = $is_tax_page ? get_field( 'tax_posts_per_page', 'options' ) :
  get_field( 'posts_per_page', $posts_page_id );
?>
<div class="posts-page-wrapper"
     data-cat-name="<?= single_term_title( '', false ) ?>"
     data-tax="<?= $is_tax_page ? 'true' : 'false' ?>">

<?php
get_footer();
