<?php
get_header();
global $post;
//$thumbnail_id = get_post_thumbnail_id( $post->ID );
//$image_alt    = get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true );
$post_id    = get_the_ID();
$author_ID  = get_post_field( 'post_author', $post_id );
$authorData = get_userdata( $author_ID );
?>
<?php if ( have_posts() ): the_post(); ?>
  <div class="single-post-wrapper">
  </div>
<?php endif; ?>
<?php
get_footer();
