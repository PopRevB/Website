import './styles/style.scss';
import {gsap} from 'gsap';
import ScrollTrigger from 'gsap/ScrollTrigger';
import header from './blocks/header_block';
import hero from './blocks/hero_block';
import {initBlocks} from './blocks';
import {barba} from "./scripts/general/barba";
import {copyLink} from './scripts/general/copy-link';
import {accordionToggle} from './scripts/general/accordion-toggle';
import {breakLine} from './scripts/functions/breakLine';
import {stickySidebar} from './scripts/functions/stickySidebar';
import {getHeightOfViewPort} from './scripts/functions/getHeightOfViewPort';
import {setFormFunctionality} from './scripts/general/set-form-functionality';
import {seeMoreLinks} from './scripts/general/see-more-links';
import {scrollToHash} from './scripts/general/scroll-to-hash';
import {pageScrollingController} from './scripts/general/page-scrolling-controller';
import {generateDataHover} from './scripts/functions/generateDataHover';
import {preloader} from "./scripts/functions/preloader";
import {initModal} from "./scripts/general/custom-modal";


const reInvokableFunction = async (container = document) => {
  try {
    container === document || eval(`
      jQuery('form.quform-form:not(.quform-ajax-initialized)').quform();
    `);
    eval(`
      jQuery(function ($) {
        var $checkboxes = $('.quform-field-1_77').click(function () {
          if ($checkboxes.filter(':checked'). length > 5) {
            $(this).prop('checked', false);
            const errorMess = document.createElement('div');
            errorMess.className = 'quform-error quform-cf flag-div';
            errorMess.style.display = 'block';
            errorMess.innerHTML = \`<div class="quform-error-inner"><span class="quform-error-text">maximum choice 5</span></div>\`;
            $('.flag-div').length === 0 ? $(this).closest('.quform-options')[0].append(errorMess) : '';
            return false;
          }
        });
      });`);
  } catch (e) {
    // do nothing
  }
  container.querySelector('.hero_block') && await hero(container.querySelector('.hero_block'));
  await initBlocks(container);

  setFormFunctionality(container);
  copyLink(container);
  scrollToHash(container);
  pageScrollingController(container);
  seeMoreLinks(container);
  accordionToggle(container);
  breakLine(container);
  stickySidebar(container);
  generateDataHover(container);
  ScrollTrigger.refresh(false);
};

let loaded = false;

async function onLoad() {
  gsap.config({
    nullTargetWarn: false,
  });
  if (document.readyState === 'complete' && !loaded) {
    loaded = true;
    initModal();
    document.body.classList.add('loaded');
    gsap.registerPlugin(ScrollTrigger);
    getHeightOfViewPort();
    document.querySelector('header') && await header(document.querySelector('header'));
    await reInvokableFunction();
    barba(reInvokableFunction);
    preloader();
  }
}

onLoad();

document.onreadystatechange = () => onLoad();
