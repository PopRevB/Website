import {gsap} from "gsap";
import {animations} from "../general/animations";

export function preloader(container = document) {
  const preloaderElm = container.querySelector(".preloader");
  if (!preloaderElm){
    container.body.style.overflow = 'hidden auto';
    document.dispatchEvent(new Event('play-hero', {bubbles: true}));
    return;
  }
  const hide = container.querySelector(".animation-content");
  const circle = container.querySelector('#circle');
  const logoWidth = parseInt(getComputedStyle(container.querySelector('.logo-wrapper')).width, 10);
  const preloaderDot = container.querySelector('.preloader-dot');
  const preloaderText = container.querySelector('.preloader-text');
  const mobileMedia = window.matchMedia('(max-width:599.98px)');
  const tl = gsap.timeline()
    .timeScale(2.5)
    .set(container.querySelectorAll('.logo g'), {opacity: 0})
    .set(container.querySelector('.animation-text'), {
      opacity: 0,
      display: "none"
    })
    .from(circle, {
      opacity: 0, scale: 0
    })
  preloaderDot?.addEventListener('click', function click() {
    preloaderDot?.removeEventListener('click', click);
    tl
      .to(preloaderText, {opacity: 0})
      .to(circle, {opacity: 1}, '<')
      .to(".logo-wrapper", {
        opacity: 1,
        scale: 1,
        duration: .8,
        ease: "ease.inOut"
      })
    moveLogoMobile()
      .to(".logo g", {opacity: 1, duration: 1, ease: "ease.inOut"})
      //moveLogoInMobile
      .to(".logo-wrapper", {scale: 1.4, ease: "ease.out", duration: .6}, "+=1")
      .to(preloaderDot, {opacity: 0, pointerEvents: 'none'}, '<')
      .to(".logo-wrapper", {
        top: "8%",
        scale: 127 / logoWidth,
        y: 0,
        x: 0,
        xPercent: -50,
        duration: 2,
        ease: "ease.out"
      }, "+=1")
      .to(".animation-text", {opacity: 1, display: "flex", duration: 2}, "<0.5")
      .to(".big-background", {opacity: 0.25, duration: 2}, "<")
      .from(".move", {y: -40, opacity: 0, duration: 2}, "<")
      .from(".rotate", {
        y: 130,
        x: -50,
        rotate: -270,
        opacity: 0,
        duration: 2
      }, "<")
      .to(".hidden", {
        top: 240,
        opacity: 0,
        display: "none",
        duration: 2,
        onComplete: preloaded
      }, "<")
  })

  function moveLogoMobile() {
    return mobileMedia.matches ? tl.to('.logo-wrapper', {
      x: 0,
      xPercent: -50,
      ease: "ease.inOut", duration: .6,
    }) : tl.addLabel('desktop');
  }

  // check if tl is completed then add listener on preloader
  function preloaded() {
    preloaderElm.classList.add('discover-site');
    preloaderElm?.addEventListener("click", function () {
      container.body.style.overflow = 'hidden auto';
      document.dispatchEvent(new Event('play-hero', {bubbles: true}));
      gsap.to(hide, {
        opacity: 0,
        display: "none",
        duration: .5,
        ease: "ease.inOut",
      })
      setTimeout(function () {
        const popup = document.querySelector('.popup_block');
        popup.classList.add("show-popup");
      }, 8000)
    })
  }

  hide.classList.remove('hidden');
}
