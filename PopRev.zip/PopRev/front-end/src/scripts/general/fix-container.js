import {pageCleaningFunctions} from "./barba";

const designWidth = 1440;
const desktop = 1440;
const tablet = 992;
const mobile = 600;
const sMobile = 393;

export function fixContainer() {
    const resizeHandler = function () {
        if (window.innerWidth >= desktop) {
            document.documentElement.style.fontSize = `${10 * window.innerWidth / desktop}px`;
        } else if (window.innerWidth < desktop && window.innerWidth >= tablet) {
            document.documentElement.style.fontSize = `${10 * window.innerWidth / designWidth}px`;
        } else if (window.innerWidth < tablet && window.innerWidth >= mobile) {
            document.documentElement.style.fontSize = `${10 * window.innerWidth / tablet}px`;
        } else if(window.innerWidth < mobile && window.innerWidth >= sMobile) {
            document.documentElement.style.fontSize = `${10}px`;
        } else {
            document.documentElement.style.fontSize = `${10 * window.innerWidth / sMobile}px`;
        }
    }

// else if (window.innerWidth < mobile && window.innerWidth >= smallMobile) {
//   document.documentElement.style.fontSize = `${10}px`;
// }

    resizeHandler();
    window.addEventListener('resize', resizeHandler);
  pageCleaningFunctions.push(() => window.removeEventListener('resize', resizeHandler))

}
