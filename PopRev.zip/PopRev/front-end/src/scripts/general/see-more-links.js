import {gsap} from "gsap";

export function seeMoreLinks(container = document) {
  const blocks = container.querySelectorAll('.financial_tips_block');
  for (let block of blocks) {
    const seeMoreLink = block.querySelector('.see-more-links'),
        hiddenLinks = block.querySelector('.right-content .links-wrapper');
    seeMoreLink?.addEventListener('click',()=>{
      seeMoreLink.classList.toggle('active');
      const collapsedHeight = window.innerWidth < 600 ? '19rem' : 'auto',
          isClosed = hiddenLinks?.classList.toggle('active');
      gsap.to(hiddenLinks, {height: isClosed ? 'auto' : collapsedHeight});
    })
  }
}