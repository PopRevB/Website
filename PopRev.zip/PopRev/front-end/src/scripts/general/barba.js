import barbajs from '@barba/core';
import {gsap} from 'gsap';

import ScrollTrigger from 'gsap/ScrollTrigger';

export const pageCleaningFunctions = [];
const clip = {top: 0, bottom: 0};

const clippedCover = {
  name: 'clipped-cover-color-transition',

  leave(data) {
    const cover = document.querySelector('.page-transition');
    return gsap.timeline({
      onUpdate() {
        cover.style.clipPath = `polygon(0% 0%, 0% 100%, ${clip.bottom}% 100%, ${clip.top}% 0%)`;
      }
    })
      // .set(cover, {backgroundColor: data.current.container.dataset.color})
      .set(cover, {backgroundColor: '#ffae00'})
      .fromTo(clip, {top: 0}, {top: 100})
      .fromTo(clip, {bottom: 0}, {bottom: 100}, '<15%')
      .call(() => window.scrollTo(0, 0))
  },
  enter(data) {
    gsap.set(data.next.container, {opacity: 0});
    gsap.set(data.current.container, {zIndex: -1, position: 'absolute'});
    window.scrollTo(0, 0);
    console.log('window.location.hash:', window.location.hash);
    // window.location.hash && window.scrollTo(0, window.scrollTop + data.next.container.querySelector(window.location.hash)?.getBoundingClientRect().top || 0)
    const cover = document.querySelector('.page-transition');
    return gsap.timeline({
      onUpdate() {
        cover.style.clipPath = `polygon(0% 0%, 0% 100%, ${clip.bottom}% 100%, ${clip.top}% 0%)`;
      },
    })
      .set(data.next.container, {opacity: 1})
      .call(() => window.scrollTo(0, 0))
      // .to(cover, {backgroundColor: data.next.container.dataset.color})
      .to(cover, {backgroundColor: '#000'})
      .fromTo(clip, {top: 100}, {top: 0})
      .fromTo(clip, {bottom: 100}, {bottom: 0}, '<25%')
  },
};
export const barba = (reInvokableFunction) => {
  console.log('barba')
  gsap.registerPlugin(ScrollTrigger);
  if (document.querySelector('[data-barba]')) {
    barbajs.init({
      transitions: [clippedCover],
      timeout: 0,
      prevent: ({el}) => el.classList?.contains('ab-item'),
    });

    barbajs.hooks.afterLeave(() => {
      window.scrollTo(0, 0);
      window.dispatchEvent(new Event('will-leave'));
      for (let scrollTrigger of ScrollTrigger.getAll()) {
        scrollTrigger.kill();
      }
      while (pageCleaningFunctions.length) {
        pageCleaningFunctions.pop()();
      }
      // gsap.globalTimeline.progress(0).clear();
      ScrollTrigger.update();
    });

    barbajs.hooks.beforeEnter(data => {
      window.scrollTo(0, 0);
      reInvokableFunction(data.next.container);
    });
    barbajs.hooks.afterEnter(({current}) => {
      window.scrollTo(0, 0);
      current.container && document.dispatchEvent(new Event('play-hero', {bubbles: true}));
      // setTimeout(function () {
      //   ScrollTrigger.refresh();
      // }, 1900);
    });

  } else {
    console.log('no barbajs container');
  }
}
