import {gsap} from "gsap";
import {ScrollTrigger} from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export function pageScrollingController() {
  const sections = document.querySelectorAll('section');
  const scrollWrapper = document.querySelector('.page-scrolling-controller');
  for (let i = 0; i < sections.length; i++) {
    const activeSectionIndicator = document.createElement('BUTTON');
    const offset = 100;
    scrollWrapper.appendChild(activeSectionIndicator);

    function activeState(isActive) {
      sections[i].classList.toggle('active-section', isActive);
      activeSectionIndicator.classList.toggle('active-bullet', isActive);
    }

    ScrollTrigger.create({
      trigger: sections[i],
      start: 'top 30%',
      end: 'bottom 30%',
      onToggle: ({isActive}) => activeState(isActive)
    })

    activeSectionIndicator?.addEventListener('click', function (e) {
      window.scrollTo({
        top: window.scrollY + sections[i].getBoundingClientRect().top - offset,
        behavior: 'smooth'
      })
    })
  }
}
