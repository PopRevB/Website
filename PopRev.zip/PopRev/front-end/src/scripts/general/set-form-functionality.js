export function setFormFunctionality(container = document) {
  const forms = container.querySelectorAll('.quform-form');
}
