import './index.html';
import './style.scss';
import {imageLazyLoading} from "../../scripts/functions/imageLazyLoading";
import {animations} from "../../scripts/general/animations";
import {Swiper} from "swiper";


const artistLogos = async (block) => {

  const swiper = new Swiper(block.querySelector('.swiper-container'), {
    slidesPerView: 2,
    spaceBetween: 50,
    breakpoints: {
      600: {
        slidesPerView: 3
      },
      992: {
        slidesPerView: 4,
        spaceBetween: 174,
      }
    }
  });


    animations(block);
    imageLazyLoading(block);
};

export default artistLogos;

