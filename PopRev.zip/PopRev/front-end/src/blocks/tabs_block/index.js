import './index.html';
import './style.scss';
import {imageLazyLoading} from '../../scripts/functions/imageLazyLoading';
import {animations} from '../../scripts/general/animations';
import {gsap} from 'gsap';


const tabsBlock = async (block) => {
  let animating = false;
  let tabs = block.querySelectorAll('.tab-links');
  let tabContent = block.querySelectorAll('.tab-content');
  for (let i = 0; i < tabs.length; i++) {
    tabs[i].addEventListener('click', function (event) {
      if (animating || tabs[i].classList.contains('active')) return;
      animating = true;
      showTabsContent(i);
    });
  }


  function hideTabsContent(j) {
    for (let i = 0; i < tabContent.length; i++) {
      if (tabContent[i].classList.contains('active')) {
        tabs[i].classList?.remove('active');
        return gsap.timeline({
          paused:true,
          onComplete: () => animating = false,
        })
          // .set(tabContent[i].querySelectorAll('.word-overflow'), {overflow: 'hidden'})
          .fromTo([...tabContent[i].querySelectorAll('.child-word')].reverse(), {
            yPercent: 0,
            opacity:1,
          }, {
            yPercent: -200,
            opacity:-1,
            stagger: 0.02,
            duration:0.65,
          })
          .fromTo(tabContent[i].querySelectorAll('.paragraph, .btn'), {
            y: 0,
            opacity:1,
          }, {
            y: -100,
            opacity:0,
            stagger: 0.15,
          },'<25%')
          .call(() => {
            tabContent[i].classList?.remove('active')
            tabContent[j].classList?.add('active')
          })
      }
    }
  }

  async function showTabsContent(i) {
    tabs[i].classList?.add('active');
    hideTabsContent(i)
      .fromTo([...tabContent[i].querySelectorAll('.child-word')].reverse(), {
        yPercent: -200,
        opacity:0,
      }, {
        yPercent: 0,
        opacity:1,
        stagger: 0.02,
        duration:0.65,
      })
      .fromTo(tabContent[i].querySelectorAll('.paragraph, .btn'), {
        y: -100,
        opacity: 0,
      }, {
        y: 0,
        opacity: 1,
        stagger: 0.15,
      },'<25%')
      .play();
  }

  animations(block);
  imageLazyLoading(block);
};

export default tabsBlock;

