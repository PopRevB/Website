import './index.html';
import './style.scss';
import {imageLazyLoading} from '../../scripts/functions/imageLazyLoading';
import {animations} from '../../scripts/general/animations';
import Swiper from 'swiper';
import 'swiper/swiper-bundle.css';

const theOpportunityBlock = async (block) => {
  const audioBoxes = block.querySelectorAll('.audio-info');
  const audios = [];
  for (let audioBox of audioBoxes) {
    const playBtn = audioBox.querySelector('.play-pause');
    const audio = document.createElement('AUDIO');
    audios.push(audio);
    audio.pause();
    audio.oncanplay = ()=>audioBox.classList.remove('audio-loading')
    audio.src = audioBox.dataset.src;

    playBtn.addEventListener('click', () => {
      if (audioBox.classList.contains('audio-loading'))return;
      audios.map((a, i) => {
        a.pause();
        audioBoxes[i] !== audioBox && audioBoxes[i].classList.remove('pause-active');
      });
      audioBox.classList.toggle('pause-active') ? audio.play() : audio.pause();
    });
  }

  const swiper = new Swiper(block.querySelector('.swiper-container'), {
    slidesPerView: 2,
    spaceBetween: 10,
    breakpoints: {
      600: {
        spaceBetween: 20,
        slidesPerView: 3,
      },
      991: {
        spaceBetween: 30,
        slidesPerView: 3,
      },
    },
  });

  animations(block);
  imageLazyLoading(block);
};

export default theOpportunityBlock;

