import './index.html';
import './style.scss';
import {gsap} from 'gsap';
import {imageLazyLoading} from '../../scripts/functions/imageLazyLoading';
import {animations} from '../../scripts/general/animations';
import {createImageRevealTimeline} from "../../scripts/general/animations/imagesRevealAnimation";

const performanceBlock = async (block) => {

  // add block code here

  const selectArtistPerformance = block.querySelectorAll('.select-wrapper select');

  for (let select of selectArtistPerformance) {
    const image = select.closest('.select-wrapper').nextElementSibling.children[0];
    const selectOption = select.querySelector('option');
    image.src = selectOption.dataset.image;
    select.addEventListener('change', function () {
      image.src = this.options[this.selectedIndex].getAttribute('data-image');
      createImageRevealTimeline(image, 'left')
    });
  }

  animations(block);
  imageLazyLoading(block);
};

export default performanceBlock;

