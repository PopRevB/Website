import './index.html';
import './style.scss';
import {Swiper} from "swiper";
import {imageLazyLoading} from "../../scripts/functions/imageLazyLoading";
import {animations} from "../../scripts/general/animations";
import {gsap} from "gsap";

const headerBlock = async (block) => {
  const tl = gsap.timeline({
    delay: 0.5, paused: true, defaults: {
      duration: 0.3
    }
  })
    .fromTo(block, {mixBlendMode: 'difference'}, {
      mixBlendMode: 'normal',
      duration: 0.01,
      immediateRender: true
    })
    .fromTo(block.querySelectorAll('.menu-parent'), {xPercent: 100}, {
      xPercent: 0,
      immediateRender: true
    })
    .fromTo(block.querySelectorAll('.menu-content .menu-item'), {
      y: 30,
      autoAlpha: 0,
    }, {
      y: 0,
      autoAlpha: 1,
      stagger: .05,
      duration: 0.2
    });
  block.querySelector(".menu").addEventListener("click", function () {
    const isActive = block.classList.toggle("active");
    isActive ? tl.play() : tl.reverse();
  })

  // region open sub menu in responsive
  const mobileMedia = window.matchMedia('(max-width: 992px)');

  const menuItems = block.querySelectorAll('.menu-content .menu-item.has-subMenu');
  menuItems.forEach((menuItem) => {
    const menuItemBody = menuItem.querySelector('.drop-down-menu');
    menuItem?.addEventListener('click', (e) => {
      if (!mobileMedia.matches) return;
      if (!menuItemBody) {
        return;
      }
      const isOpened = menuItem?.classList.toggle('active-page');
      if (!isOpened) {
        gsap.to(menuItemBody, {height: 0});
      } else {
        gsap.to(Array.from(menuItems).map(otherFaq => {
          const otherFaqBody = otherFaq.querySelector('.drop-down-menu');
          if (otherFaqBody && menuItem !== otherFaq) {
            otherFaq?.classList.remove('active-page');
            gsap.set(otherFaq, {zIndex: 1});
          }
          return otherFaqBody;
        }), {height: 0});
        gsap.set(menuItem, {zIndex: 2});
        gsap.to(menuItemBody, {height: 'auto'});
      }
    });
  });
  // endregion open sub menu in responsive

  const menuLink = block.querySelectorAll(".menu-item");
  menuLink.forEach((link) => {
    link.addEventListener('click', function (e) {
      if (e.target.href !== '#' && e.target.href !== undefined) {
        block.classList.remove("active");
        tl.reverse();
      }
      if (link.classList.contains('active')) {
        link.classList.remove('active');
      } else {
        menuLink.forEach((link) => {
          link.classList.remove('active');
        });
        link.classList.add('active');
      }
    });
  });

  const mediaDesktop = window.matchMedia('(min-width:992px)');
  if (mediaDesktop.matches) {
    const activeBorder = block.querySelector('.active-border');
    const menuWrapper = block.querySelector('.menu-wrapper');
    const spaceDifference = window.innerWidth - menuWrapper.clientWidth;

    menuLink.forEach((link) => {
      link.addEventListener('mouseover', () => {
        const linkRect = link.getBoundingClientRect();
        activeBorder.style.left = linkRect.x - spaceDifference + 'px';
        activeBorder.style.width = linkRect.width + 'px';
      })
    })
  }

  let media = window.matchMedia('(min-width: 992px)');
  const swiperContainer = block.querySelector('.swiper-container');
  swiperContainer && media.matches ? new Swiper(block.querySelector('.swiper-container'), {
    slidesPerView: 'auto',
    spaceBetween: 0,
  }) : '';


  animations(block);
  imageLazyLoading(block);
};

export default headerBlock;


