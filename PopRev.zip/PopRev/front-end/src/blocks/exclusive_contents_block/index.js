import './index.html';
import './style.scss';
import {imageLazyLoading} from "../../scripts/functions/imageLazyLoading";
import {animations} from "../../scripts/general/animations";
import {Swiper} from 'swiper';


const exclusiveContentsBlock = async (block) => {

  // add block code here
  new Swiper(block.querySelector('.swiper-container'), {
    slidesPerView: 1.6,
    spaceBetween: 28,
    breakpoints: {
      600: {
        slidesPerView: 2.6,
        spaceBetween: 24,
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 35,
      }
    }
  })


  animations(block);
  imageLazyLoading(block);
};

export default exclusiveContentsBlock;

