import './index.html';
import './style.scss';
import {imageLazyLoading} from "../../scripts/functions/imageLazyLoading";
import {animations} from "../../scripts/general/animations";
import {gsap} from "gsap";
import {SplitText} from 'gsap/SplitText';
import {createImageRevealTimeline} from "../../scripts/general/animations/imagesRevealAnimation";
import {pageCleaningFunctions} from "../../scripts/general/barba";


const heroBlock = async (block) => {

  const splitWords = element => {
    new SplitText(element, {
      type: 'words',
      wordsClass: 'word-overflow',
    });
    const splitWords = new SplitText(element, {
      type: 'words',
      wordsClass: 'child-word',
    });
    gsap.set(splitWords.words, {yPercent: 100});
    return splitWords;
  }

  const tl = gsap.timeline({paused: true})
  const heroImage = block.querySelector('.hero-image');
  const title = splitWords(block.querySelector('.headline-1'));
  const paragraph = block.querySelector('.paragraph-18');
  const button = block.querySelectorAll('.button-animation');
  tl.add(
    gsap.timeline()
      .to(title.words, {yPercent: 0, duration: 0.35, stagger: 0.05})
      .set(title.words.map(e => e.parentElement), {overflow: 'visible'}, '-=.2'),
    0)
    .fromTo(paragraph, {
      autoAlpha: 0,
      y: 80,
    }, {
      duration: .7,
      autoAlpha: 1,
      yPercent: 0,
      y: 0,
      ease: 'power1.out',
      stagger: .1,
      clearProps: 'transform',
    }, '<0.4')
    .fromTo(button, {
      autoAlpha: 0,
      y: 80,
    }, {
      duration: .7,
      autoAlpha: 1,
      yPercent: 0,
      y: 0,
      ease: 'power1.out',
      stagger: .1,
      clearProps: 'transform',
    }, '<0.1')
    .add(createImageRevealTimeline(heroImage, 'right'), '<-0.3')


  const playHero = () => {
    console.log('play - hero');
    tl.play();
  }
  document.addEventListener("play-hero", playHero);
  pageCleaningFunctions.push(() => document.removeEventListener('play-hero', playHero))
  animations(block);
  imageLazyLoading(block);
};

export default heroBlock;

