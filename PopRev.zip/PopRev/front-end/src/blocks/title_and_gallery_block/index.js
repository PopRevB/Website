import './index.html';
import './style.scss';
import {imageLazyLoading} from "../../scripts/functions/imageLazyLoading";
import {animations} from "../../scripts/general/animations";
import {Swiper} from "swiper";

const titleAndGalleryBlock = async (block) => {

  // add block code here
  new Swiper(block.querySelector('.swiper-container'), {
    slidesPerView: 1.34,
    spaceBetween: 15,
    breakpoints: {
      600: {
        slidesPerView: 2.5,
        spaceBetween: 18,
      },
      992: {
        slidesPerView: 4,
        spaceBetween: 24,
      }
    }
  })

  animations(block);
  imageLazyLoading(block);
};

export default titleAndGalleryBlock;

