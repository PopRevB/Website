import './index.html';
import './style.scss';
import {imageLazyLoading} from "../../scripts/functions/imageLazyLoading";
import {animations} from "../../scripts/general/animations";
import {Swiper, Pagination} from "swiper";
import {customModal} from "../../scripts/general/custom-modal";

Swiper.use([Pagination])
const artistQuoteBlock = async (block) => {

  // add block code here

  new Swiper(block.querySelector('.swiper-container'), {
    slidesPerView: 1,
    spaceBetween: 20,
    pagination: {
      el: block.querySelector('.swiper-pagination'),
      clickable: true,
    }
  })

  const slides = block.querySelectorAll('.swiper-slide');
  for (let slide of slides) {
    const videoWrapper = slide.querySelector('.video-wrapper');
    const toggler = slide.querySelector('.watch-interview');
    customModal(toggler, videoWrapper);
  }

  animations(block);
  imageLazyLoading(block);
};

export default artistQuoteBlock;

