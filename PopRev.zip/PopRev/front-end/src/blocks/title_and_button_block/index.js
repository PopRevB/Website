import './index.html';
import './style.scss';
import {imageLazyLoading} from "../../scripts/functions/imageLazyLoading";
import {animations} from "../../scripts/general/animations";
import {gsap} from "gsap";
import {ScrollTrigger} from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger)
const titleAndButtonBlock = async (block) => {


  ScrollTrigger.create({
    trigger: block,
    start: 'top 30%',
    end: 'bottom 30%',
    once: true,
    onEnter: () => block.classList.add('active-black')
  })


  animations(block);
  imageLazyLoading(block);
};

export default titleAndButtonBlock;

