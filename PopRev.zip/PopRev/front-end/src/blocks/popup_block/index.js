import './index.html';
import './style.scss';
import {imageLazyLoading} from "../../scripts/functions/imageLazyLoading";
import {animations} from "../../scripts/general/animations";


const popupBlock = async (block) => {


  block.querySelector(".close-icon").addEventListener("click", function () {
    block.classList.remove("show-popup")
  })

  animations(block);
  imageLazyLoading(block);
};

export default popupBlock;

