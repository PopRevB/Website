import './index.html';
import './style.scss';
import {imageLazyLoading} from "../../scripts/functions/imageLazyLoading";
import {animations} from "../../scripts/general/animations";


const artistAfricansBlock = async (block) => {

  // add block code here
  // const dashedBorder = block.querySelector('.yellow-dashed-border');
  // const sectionHeight = dashedBorder.getBoundingClientRect().height;
  // const lineHeight = 10;
  // const space = 10;
  //
  // const numberOfLines = ~~(sectionHeight / (lineHeight + space));
  //
  // for (let i = 0; i < numberOfLines; i++) {
  //   let line = document.createElement('span');
  //   dashedBorder.appendChild(line);
  // }

  animations(block);
  imageLazyLoading(block);
};

export default artistAfricansBlock;

