/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkpoprev"] = self["webpackChunkpoprev"] || []).push([["src_blocks_logos_block_index_html"],{

/***/ "./src/blocks/logos_block/index.html":
/*!*******************************************!*\
  !*** ./src/blocks/logos_block/index.html ***!
  \*******************************************/
/***/ (function() {

eval("\n\n//# sourceURL=webpack://poprev/./src/blocks/logos_block/index.html?");

/***/ })

}]);